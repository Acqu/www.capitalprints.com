﻿function toggleMenu() {
    var menu = document.querySelector('.nav');
    menu.classList.toggle('active');
}

